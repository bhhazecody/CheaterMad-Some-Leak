#pragma once
#include <iostream>
#include <vector>

namespace Settings
{
	static int Tab = 0;
	static int malyusuf = 0;
	static int malege = 0;
}