#define LOCALPLAYER 0x1e4f288   //updated
#define CL_ENTITYLIST 0x1a9e778 //updated
#define CLIENTSTATE 0x13c3c80 //updated
#define CGLOBALVAR 0x13c3990 //updated
#define RENDER 0x75cc210 //updated
#define MATRIX 0x11a210 //updated
#define M_INAME 0x0589 //updated
#define M_ITEAMNUM 0x044c  //updated
#define LASTVISIBLETIME 0x1a48 //updated
#define m_ammoPoolCapacity 0x253c //updated
#define ORIGIN 0x14c  //m_vecAbsOrigin updated
#define BONES  0xED0//m_nForceBone updated 0x0e88  + 0x50 - 0x8
#define VIEWANGLES m_ammoPoolCapacity - 0x14 //updated
#define AIMPUNCH 0x2440 //m_currentFrameLocalPlayer.m_vecPunchWeapon_Angle updated
#define M_LASTESTPRIMARYWINDOWS 0x19ec //m_latestPrimaryWeapons updated
#define NSKIN 0x0e48 //m_nSkin updated
#define IN_JUMP 0x07546398 //updated
#define LIFESTATE 0x798   //m_lifeState updated
#define BLEEDOUTSTATE 0x26d0 //m_bleedoutState updated
#define BULLET_SPEED 0x1ed0 //CWeaponX!m_flProjectileSpeed updated
#define BULLET_SCALE 0x1ed8 //CWeaponX!m_flProjectileScale updated
#define CAMERAPOS 0x1ee0 //CPlayer!camera_origin updated
#define ITEM_ID 0x1628
#define GLOW_ENABLE 0x3c8
#define GLOW_THROUGH_WALLS 0x3d0
#define GLOW_TYPE 0x2C4
#define GLOW_R 0x1D0
#define GLOW_G 0x1D4
#define GLOW_B 0x1D8
